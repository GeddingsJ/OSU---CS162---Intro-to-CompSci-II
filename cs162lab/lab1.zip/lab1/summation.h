
#ifndef summation_h
#define summation_h

double sum (int size, int array[]);

#endif
