
#ifndef average_h
#define average_h

double avg (int size, int array[]);

#endif
